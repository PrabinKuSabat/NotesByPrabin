# Hostel Weekly Menu Browser App

This package gives a simple browser-based interface for the hostel weekly menu generator.

The older user does **not** need to type Python command-line options.

## What the user does

1. Open the folder.
2. Double-click the launcher for their system:
   - Windows: `start_menu_app_windows.bat`
   - Linux/Mac: `start_menu_app_linux_mac.sh`
3. A browser page opens.
4. Choose:
   - week starting Monday
   - number of students
   - budget per person for the week
   - budget tolerance
5. Click **Generate Weekly Menu**.
6. Click **Download Excel Menu**.

## Files included

- `menu_web_app.py` — browser interface.
- `weekly_menu_generator_budget.py` — backend generator logic.
- `hostel_menu_database.xlsx` — current menu database with normalized items and sample prices.
- `requirements.txt` — required Python packages.
- `start_menu_app_windows.bat` — Windows launcher.
- `start_menu_app_linux_mac.sh` — Linux/Mac launcher.

## Price updates

Update item prices in:

`hostel_menu_database.xlsx -> Normalized_Items -> Editable_Price_INR`

Then open the app again. The generator will use the updated prices.

The browser app also allows uploading an updated workbook manually.

## Advanced settings

The normal screen hides most technical settings. Advanced settings are available inside the **Advanced settings** dropdown:

- Fruits per week
- Salads per week
- Veg curry per week
- Lunch specials per week
- Dinner specials per week
- Generation attempts
- Max candidates per meal
- Fixed/random seed

## Notes

- The app runs locally on the computer.
- It uses a browser only as the interface.
- It does not upload hostel data to a website.
- First launch may take some time because Python installs required packages.
