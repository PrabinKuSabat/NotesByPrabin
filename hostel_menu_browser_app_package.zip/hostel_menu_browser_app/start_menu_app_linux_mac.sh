#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "Installing required packages if missing..."
python3 -m pip install -r requirements.txt
echo "Starting Hostel Menu App..."
python3 -m streamlit run menu_web_app.py
