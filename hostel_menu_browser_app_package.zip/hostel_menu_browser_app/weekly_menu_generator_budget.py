#!/usr/bin/env python3
"""
Hostel weekly menu generator from hostel_menu_consolidated_2012_2025.xlsx.

Install:
    pip install pandas openpyxl

Run:
    python weekly_menu_generator.py --input hostel_menu_consolidated_2012_2025.xlsx --output weekly_menu.xlsx --week-start 2026-06-22 --seed 42

Notes:
- Approved duplicate mappings from the chat are already included.
- The output workbook contains Weekly_Menu, Rule_Audit, Selected_Details, Updated_Used_Log, Alias_Map, Taxonomy_Auto_Tags, Candidate_Database.
- Sambar is NOT counted as a pulse item by default. Add it to PULSE_KEYWORDS if your hostel wants it counted.
"""

from __future__ import annotations

import argparse
import math
import random
import re
from dataclasses import dataclass, asdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

# ---------------------------------------------------------------------
# Approved aliases: confirmed 1-14 YES, 15 canonical = potato.
# ---------------------------------------------------------------------
APPROVED_ALIAS_MAP: Dict[str, str] = {
    "w peas curry": "white peas curry", "w pea curry": "white peas curry", "whitepeas curry": "white peas curry", "white pea curry": "white peas curry",
    "w peas": "white peas", "w pea": "white peas", "whitepeas": "white peas", "white pea": "white peas",
    "g peas curry": "green peas curry", "greenpeas curry": "green peas curry", "g peas": "green peas", "greenpeas": "green peas",
    "w peas chaat": "white peas chaat", "w peas chat": "white peas chaat", "white peas chat": "white peas chaat", "whitepeas chat": "white peas chaat", "whitepeas chaat": "white peas chaat",
    "chapati": "chapathi", "chapathi": "chapathi",
    "cabbe curry": "cabbage curry", "cabb curry": "cabbage curry", "cab curry": "cabbage curry", "cabbe": "cabbage", "cabb": "cabbage",
    "carr dry curry": "carrot dry curry", "carre dry curry": "carrot dry curry", "carr": "carrot", "carre": "carrot",
    "tom dal": "tomato dal", "tom rasam": "tomato rasam", "tom rice": "tomato rice", "tom": "tomato",
    "chat": "chaat",
    "kala chena curry": "kala chana curry", "kala chenna curry": "kala chana curry", "kala chena": "kala chana", "kala chenna": "kala chana",
    "kabuli chena curry": "kabuli chana curry", "kabuli chena": "kabuli chana",
    "caulifloer": "cauliflower", "cauliflow": "cauliflower", "caulifl": "cauliflower", "gobi": "cauliflower",
    "aloo": "potato",
}

EXTRA_ALIAS_MAP: Dict[str, str] = {
    "idali": "idli", "idly": "idli", "bm": "buttermilk", "butter milk": "buttermilk",
    "poori": "puri", "uthappam": "uttapam", "uttappa": "uttapam", "parota": "paratha", "porotta": "paratha",
    "chole": "chana curry", "chola": "chana curry",
}
ALIAS_MAP = {**EXTRA_ALIAS_MAP, **APPROVED_ALIAS_MAP}
ALIAS_KEYS_BY_LENGTH = sorted(ALIAS_MAP, key=len, reverse=True)

# ---------------------------------------------------------------------
# Taxonomy seed. Edit these sets if your hostel classifies items differently.
# ---------------------------------------------------------------------
FRUIT_KEYWORDS = {"banana", "guava", "apple", "orange", "mango", "papaya", "watermelon", "musk melon", "muskmelon", "pineapple", "grapes", "sweet lime", "pomegranate", "fruit", "fruits"}
CUT_FRUIT_KEYWORDS = {"cut fruit", "cut fruits", "mixed fruit", "fruit salad", "fruits"}
SALAD_KEYWORDS = {"salad", "cucumber slices", "kosambari", "kachumber"}
PULSE_KEYWORDS = {"dal", "dhal", "chana", "channa", "chenna", "chickpea", "rajma", "white peas", "green peas", "peas curry", "peas chaat", "sprouts", "moong", "green gram", "black gram", "horse gram", "cowpea", "lobia", "sundal", "kala chana", "kabuli chana"}
VEGETABLE_KEYWORDS = {"potato", "cabbage", "carrot", "beans", "palak", "spinach", "brinjal", "eggplant", "cauliflower", "beetroot", "bottle gourd", "ridge gourd", "snake gourd", "pumpkin", "okra", "ladies finger", "bhindi", "capsicum", "tomato", "onion", "drumstick", "raw banana", "plantain", "radish", "cucumber", "knol khol", "turnip", "green leaves", "methi", "mushroom"}
VEG_CURRY_WORDS = {"curry", "dry curry", "masala", "kurma", "korma", "kura", "sabji", "subji"}
DEEP_FRIED_KEYWORDS = {"vada", "bonda", "bajji", "pakoda", "pakora", "samosa", "cutlet", "puri", "poori", "chips", "papad", "appalam"}
GRIDDLED_KEYWORDS = {"dosa", "chapathi", "chapati", "roti", "paratha", "parota", "porotta", "uttapam", "uthappam", "pesarattu", "thepla", "phulka"}
STEAMED_KEYWORDS = {"idli", "idly", "puttu", "idiyappam", "steamed"}

MEAL_ORDER = ["Breakfast", "Lunch", "Snacks/Tea", "Dinner"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

@dataclass(frozen=True)
class Candidate:
    meal_type: str
    combo: str
    key: str
    items: Tuple[str, ...]
    source_years: str
    count: int
    last_seen: Optional[pd.Timestamp]
    special: bool
    special_type: str
    has_fruit: bool
    has_cut_fruit: bool
    has_salad: bool
    has_veg_curry: bool
    has_pulse: bool
    fried_count: int
    griddled_count: int
    steamed_count: int
    pulse_count: int

@dataclass
class Slot:
    day: str
    date: date
    meal: str
    c: Candidate
    addons: str = ""
    notes: str = ""

# ---------------------------------------------------------------------
# Normalization and tagging
# ---------------------------------------------------------------------
def clean_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()

def basic_clean(s: str) -> str:
    s = str(s or "").lower().replace("\u00a0", " ")
    s = s.replace("–", "-").replace("—", "-")
    s = s.replace("/", " | ").replace("+", " | ").replace(";", " | ")
    s = re.sub(r"[()\[\]{}]", " ", s)
    s = re.sub(r"\b\d+\s*(am|pm|kg|g|gm|ml|ltr|lt|nos?)\b", " ", s)
    s = re.sub(r"\b\d+\b", " ", s)
    s = re.sub(r"[^a-z0-9|, &.-]+", " ", s).replace("&", " and ")
    return clean_spaces(s)

def apply_aliases(s: str) -> str:
    s = clean_spaces(s)
    if s in ALIAS_MAP:
        return ALIAS_MAP[s]
    for a in ALIAS_KEYS_BY_LENGTH:
        s = re.sub(r"(?<![a-z0-9])" + re.escape(a) + r"(?![a-z0-9])", ALIAS_MAP[a], s)
    return clean_spaces(s)

def normalize_item(item: str) -> str:
    return clean_spaces(apply_aliases(basic_clean(item).strip(" |,.-")).strip(" |,.-"))

def split_combo(combo: str) -> List[str]:
    parts = re.split(r"\s*\|\s*|\s*,\s*", basic_clean(combo))
    out = [normalize_item(p) for p in parts]
    return [x for x in out if x and x not in {"nil", "none", "nan", "-"}]

def canonical_combo(combo: str) -> Tuple[str, str, Tuple[str, ...]]:
    seen, ordered = set(), []
    for item in split_combo(combo):
        if item not in seen:
            ordered.append(item); seen.add(item)
    return " | ".join(ordered), " || ".join(sorted(seen)), tuple(ordered)

def contains_any(text: str, words: Iterable[str]) -> bool:
    return any(w in text for w in words)

def item_tags(item: str) -> Dict[str, bool]:
    item = normalize_item(item)
    cut_fruit = contains_any(item, CUT_FRUIT_KEYWORDS)
    fruit = cut_fruit or contains_any(item, FRUIT_KEYWORDS)
    salad = contains_any(item, SALAD_KEYWORDS)
    pulse = contains_any(item, PULSE_KEYWORDS)
    veg_curry = contains_any(item, VEGETABLE_KEYWORDS) and contains_any(item, VEG_CURRY_WORDS) and not pulse
    return {
        "fruit": fruit, "cut_fruit": cut_fruit, "salad": salad, "veg_curry": veg_curry, "pulse": pulse,
        "fried": contains_any(item, DEEP_FRIED_KEYWORDS),
        "griddled": contains_any(item, GRIDDLED_KEYWORDS),
        "steamed": contains_any(item, STEAMED_KEYWORDS),
    }

def combo_tags(items: Sequence[str]) -> Dict[str, object]:
    ts = [item_tags(i) for i in items]
    return {
        "has_fruit": any(t["fruit"] for t in ts),
        "has_cut_fruit": any(t["cut_fruit"] for t in ts),
        "has_salad": any(t["salad"] for t in ts),
        "has_veg_curry": any(t["veg_curry"] for t in ts),
        "has_pulse": any(t["pulse"] for t in ts),
        "fried_count": sum(t["fried"] for t in ts),
        "griddled_count": sum(t["griddled"] for t in ts),
        "steamed_count": sum(t["steamed"] for t in ts),
        "pulse_count": sum(t["pulse"] for t in ts),
    }

# ---------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------
def parse_excel_date(s: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_datetime(s, unit="D", origin="1899-12-30", errors="coerce")
    out = pd.to_datetime(s, errors="coerce")
    bad = out.isna() & s.notna()
    if bad.any():
        nums = pd.to_numeric(s[bad], errors="coerce")
        out.loc[bad] = pd.to_datetime(nums, unit="D", origin="1899-12-30", errors="coerce")
    return out

def load_used_log(path: Optional[str]) -> pd.DataFrame:
    if not path or not Path(path).exists():
        return pd.DataFrame(columns=["key", "last_used_date"])
    df = pd.read_excel(path) if Path(path).suffix.lower().startswith(".xls") else pd.read_csv(path)
    if "normalized_key" in df.columns and "key" not in df.columns:
        df = df.rename(columns={"normalized_key": "key"})
    if "key" not in df.columns:
        return pd.DataFrame(columns=["key", "last_used_date"])
    df["last_used_date"] = pd.to_datetime(df.get("last_used_date"), errors="coerce")
    return df[["key", "last_used_date"]]

def build_candidates(input_path: str) -> List[Candidate]:
    """
    Build candidate combos quickly from Master_Deduped when available.
    This avoids re-parsing all 19k raw date rows every time.
    """
    try:
        master = pd.read_excel(input_path, sheet_name="Master_Deduped")
    except Exception:
        master = None

    out: List[Candidate] = []
    if master is not None and not master.empty and {"Meal_Type", "Normalized_Key"}.issubset(set(master.columns)):
        master.columns = [str(c).strip() for c in master.columns]
        master = master[master["Meal_Type"].astype(str).str.strip().isin(MEAL_ORDER)].copy()
        for _, r in master.iterrows():
            meal = str(r.get("Meal_Type", "")).strip()
            key = clean_spaces(str(r.get("Normalized_Key", "") or ""))
            combo = clean_spaces(str(r.get("Normalized_Combo", "") or r.get("Canonical_Combo", "") or ""))
            if not key and combo:
                combo, key, items = canonical_combo(combo)
            else:
                items = tuple(normalize_item(x) for x in re.split(r"\s*\|\|\s*", key) if normalize_item(x))
                if not combo:
                    combo = " | ".join(items)
            if not key or not items:
                continue
            tags = combo_tags(items)
            years = clean_spaces(str(r.get("Distinct_Years", "")))
            count = int(pd.to_numeric(r.get("Occurrences", 1), errors="coerce") if pd.notna(r.get("Occurrences", 1)) else 1)
            last_seen = pd.to_datetime(r.get("Last_Date"), errors="coerce")
            special_seen = str(r.get("Special_Seen", "")).strip().lower() in {"yes", "true", "1"}
            special_occ = int(pd.to_numeric(r.get("Special_Occurrences", 0), errors="coerce") or 0)
            out.append(Candidate(
                meal_type=meal, combo=combo, key=key, items=tuple(items),
                source_years=years, count=count,
                last_seen=None if pd.isna(last_seen) else last_seen,
                special=bool(special_seen or special_occ > 0),
                special_type="Special" if (special_seen or special_occ > 0) else "",
                has_fruit=bool(tags["has_fruit"]), has_cut_fruit=bool(tags["has_cut_fruit"]),
                has_salad=bool(tags["has_salad"]), has_veg_curry=bool(tags["has_veg_curry"]),
                has_pulse=bool(tags["has_pulse"]), fried_count=int(tags["fried_count"]),
                griddled_count=int(tags["griddled_count"]), steamed_count=int(tags["steamed_count"]),
                pulse_count=int(tags["pulse_count"]),
            ))
        return out

    # Fallback: raw extraction path.
    raw = pd.read_excel(input_path, sheet_name="Raw_Extracted")
    raw.columns = [str(c).strip() for c in raw.columns]
    raw["Date_parsed"] = parse_excel_date(raw["Date"])
    raw = raw[raw["Meal_Type"].astype(str).str.strip().isin(MEAL_ORDER)].copy()
    raw = raw[raw["Normalized_Combo"].notna()].copy()
    rows = []
    for _, r in raw.iterrows():
        combo, key, items = canonical_combo(str(r.get("Normalized_Combo") or r.get("Raw_Combo") or ""))
        if not key:
            continue
        tags = combo_tags(items)
        rows.append({
            "meal": str(r["Meal_Type"]).strip(), "combo": combo, "key": key, "items": items,
            "year": r.get("Year"), "date": r.get("Date_parsed"),
            "special": bool(r.get("Special_Flag", False)), "special_type": clean_spaces(r.get("Special_Type", "")), **tags,
        })
    df = pd.DataFrame(rows)
    for (meal, key), g in df.groupby(["meal", "key"]):
        first = g.iloc[0]
        years = sorted({int(y) for y in pd.to_numeric(g["year"], errors="coerce").dropna().unique()})
        last_seen = pd.to_datetime(g["date"], errors="coerce").max()
        out.append(Candidate(
            meal_type=str(meal), combo=str(first["combo"]), key=str(key), items=tuple(first["items"]),
            source_years=", ".join(map(str, years)), count=int(len(g)),
            last_seen=None if pd.isna(last_seen) else last_seen,
            special=bool(g["special"].fillna(False).any()),
            special_type="; ".join(sorted({str(x) for x in g["special_type"].dropna().unique() if str(x).strip()})),
            has_fruit=bool(first["has_fruit"]), has_cut_fruit=bool(first["has_cut_fruit"]), has_salad=bool(first["has_salad"]),
            has_veg_curry=bool(first["has_veg_curry"]), has_pulse=bool(first["has_pulse"]),
            fried_count=int(first["fried_count"]), griddled_count=int(first["griddled_count"]), steamed_count=int(first["steamed_count"]), pulse_count=int(first["pulse_count"]),
        ))
    return out


# ---------------------------------------------------------------------
# Budget / item master pricing
# ---------------------------------------------------------------------
DEFAULT_SAMPLE_PRICES_INR = {
    "rice": 5, "chapathi": 5, "roti": 5, "paratha": 9, "parotta": 10, "puri": 12,
    "idli": 8, "rava idli": 10, "dosa": 10, "set dosa": 12, "masala dosa": 16,
    "uttapam": 13, "pesarattu": 14, "upma": 10, "rava upma": 10, "semiya upma": 11,
    "poha": 10, "pongal": 14, "sambar": 7, "rasam": 4, "curd": 7,
    "buttermilk": 4, "masala buttermilk": 5, "raita": 8, "chutney": 3,
    "groundnut chutney": 4, "coconut chutney": 5, "coriander chutney": 4,
    "tomato chutney": 4, "pickle": 1, "papad": 3, "tea": 3, "coffee": 4,
    "milk": 8, "juice": 8, "banana": 5, "guava": 7, "cut fruits": 12,
    "fruit": 10, "green salad": 5, "vada": 8, "bonda": 8, "bajji": 8,
    "pakoda": 9, "samosa": 10, "cutlet": 12, "curd rice": 12, "tomato rice": 12,
    "lemon rice": 11, "fried rice": 16, "vegetable fried rice": 18, "pulao": 18,
    "biryani": 25, "noodles": 18, "macaroni": 16, "pasta": 18, "pav bhaji": 20,
    "payasam": 12, "kesari": 8, "gulab jamun": 12, "ice cream": 15,
}

NON_FOOD_TERMS = {
    "summer vacation", "no food", "no breakfast", "no lunch", "no dinner",
    "canteen", "holiday", "vacation", "last day", "notice", "staff", "students",
    "workers", "income tax", "less", "balance", "left out"
}

def item_price_fallback(item: str) -> float:
    item = normalize_item(item)
    if item in DEFAULT_SAMPLE_PRICES_INR:
        return float(DEFAULT_SAMPLE_PRICES_INR[item])
    if "paneer" in item:
        return 25.0
    if "mushroom" in item:
        return 20.0
    if "biryani" in item or "pulao" in item or "pulav" in item:
        return 20.0
    if "fried rice" in item:
        return 18.0
    if "rice" in item:
        return 12.0
    if any(w in item for w in ["dal", "chana", "peas", "rajma", "sprouts"]):
        return 13.0
    if any(w in item for w in ["curry", "kurma", "gravy", "masala"]):
        return 12.0
    if "chutney" in item:
        return 4.0
    if "salad" in item:
        return 5.0
    if "fruit" in item:
        return 10.0
    if any(w in item for w in ["vada", "bonda", "bajji", "pakoda", "samosa", "cutlet", "puri"]):
        return 10.0
    return 10.0

def load_price_map(input_path: str) -> Dict[str, float]:
    """Load editable item prices from Normalized_Items if the sheet exists; otherwise use fallback prices."""
    price_map: Dict[str, float] = {}
    try:
        xls = pd.ExcelFile(input_path)
        if "Normalized_Items" in xls.sheet_names:
            df = pd.read_excel(input_path, sheet_name="Normalized_Items")
            cols = {str(c).strip(): c for c in df.columns}
            item_col = cols.get("Canonical_Item")
            price_col = cols.get("Editable_Price_INR") or cols.get("Sample_Cost_INR_Per_Person")
            active_col = cols.get("Usable_For_Generator")
            if item_col and price_col:
                for _, r in df.iterrows():
                    item = normalize_item(r.get(item_col, ""))
                    if not item:
                        continue
                    if active_col and str(r.get(active_col, "")).strip().lower() in {"false", "no", "0"}:
                        continue
                    price = pd.to_numeric(r.get(price_col), errors="coerce")
                    if pd.notna(price):
                        price_map[item] = float(price)
    except Exception:
        pass
    return price_map

def get_item_price(item: str, price_map: Dict[str, float]) -> float:
    item = normalize_item(item)
    return float(price_map.get(item, item_price_fallback(item)))

def addon_items(addons: str) -> List[str]:
    return [normalize_item(x) for x in str(addons or "").split("|") if normalize_item(x)]

def candidate_cost(c: Candidate, price_map: Dict[str, float]) -> float:
    return round(sum(get_item_price(i, price_map) for i in c.items), 2)

def slot_cost(s: Slot, price_map: Dict[str, float]) -> float:
    return round(candidate_cost(s.c, price_map) + sum(get_item_price(i, price_map) for i in addon_items(s.addons)), 2)

def day_cost(slots: List[Slot], day: str, price_map: Dict[str, float]) -> float:
    return round(sum(slot_cost(s, price_map) for s in slots if s.day == day), 2)

def is_non_food_candidate(c: Candidate) -> bool:
    text = (c.combo + " " + " ".join(c.items)).lower()
    return any(t in text for t in NON_FOOD_TERMS)

# ---------------------------------------------------------------------
# Generator and rule audit
# ---------------------------------------------------------------------
def invalid_candidate(c: Candidate) -> Tuple[bool, str]:
    if is_non_food_candidate(c): return True, "non-food/admin/vacation entry"
    if c.has_veg_curry and c.has_cut_fruit: return True, "veg curry with cut fruit"
    if c.griddled_count > 1: return True, "more than one griddled item"
    if c.griddled_count > 0 and c.steamed_count > 0: return True, "griddled + steamed mains"
    return False, ""

def age_weight(c: Candidate, today: date, used: Dict[str, pd.Timestamp], need_veg: int, rng: random.Random) -> float:
    last = used.get(c.key, c.last_seen)
    days = 9999 if last is None or pd.isna(last) else max(0, (pd.Timestamp(today) - pd.Timestamp(last).normalize()).days)
    age = min(days / 365, 10) + 1
    freq = 1 / math.sqrt(max(c.count, 1))
    veg = 1.8 if need_veg > 0 and c.has_veg_curry and c.meal_type in {"Lunch", "Dinner"} else 1
    special_penalty = 0.75 if c.special else 1
    return max(0.001, age * freq * veg * special_penalty * rng.uniform(0.85, 1.15))

def choose(pool: Sequence[Candidate], weights: Sequence[float], rng: random.Random) -> Candidate:
    total = sum(weights)
    if total <= 0:
        return rng.choice(list(pool))
    x, acc = rng.random() * total, 0.0
    for c, w in zip(pool, weights):
        acc += w
        if acc >= x: return c
    return pool[-1]

def add_sides(slots: List[Slot], rng: random.Random, fruits: int, salads: int) -> None:
    fruit_count = sum(s.c.has_fruit for s in slots)
    salad_count = sum(s.c.has_salad for s in slots)
    fruit_slots = [s for s in slots if s.meal in {"Lunch", "Dinner"} and not s.c.has_fruit]
    rng.shuffle(fruit_slots)
    for s in fruit_slots:
        if fruit_count >= fruits: break
        if s.c.has_veg_curry:
            fruit, note = rng.choice(["banana", "guava"]), "fruit added; veg curry present, so no cut fruit"
        elif s.c.has_pulse:
            fruit, note = "cut fruits", "cut fruits added with pulse item"
        else:
            fruit, note = rng.choice(["banana", "guava", "cut fruits"]), "fruit added"
        s.addons = clean_spaces(" | ".join(x for x in [s.addons, fruit] if x))
        s.notes = clean_spaces("; ".join(x for x in [s.notes, note] if x))
        fruit_count += 1
    salad_slots = [s for s in slots if s.meal in {"Lunch", "Dinner"} and not s.c.has_salad]
    rng.shuffle(salad_slots)
    for s in salad_slots:
        if salad_count >= salads: break
        s.addons = clean_spaces(" | ".join(x for x in [s.addons, "green salad"] if x))
        s.notes = clean_spaces("; ".join(x for x in [s.notes, "salad added"] if x))
        salad_count += 1

def audit_plan(slots: List[Slot], args, price_map: Dict[str, float]) -> Tuple[int, List[Dict[str, object]]]:
    rows, score = [], 0
    def rule(name, ok, detail, penalty):
        nonlocal score
        if not ok: score += penalty
        rows.append({"Rule": name, "Pass": bool(ok), "Detail": detail, "Penalty": 0 if ok else penalty})

    fruit_count = sum(s.c.has_fruit or any(x in s.addons for x in ["banana", "guava", "cut fruits"]) for s in slots)
    salad_count = sum(s.c.has_salad or "salad" in s.addons for s in slots)
    veg_count = sum(s.c.has_veg_curry for s in slots)
    rule("Fruits at least 3/week", fruit_count >= args.fruits_per_week, f"fruit_count={fruit_count}", 100 * max(0, args.fruits_per_week - fruit_count))
    rule("Salads at least 3/week", salad_count >= args.salads_per_week, f"salad_count={salad_count}", 100 * max(0, args.salads_per_week - salad_count))
    rule("Veg curry at least 3/week", veg_count >= args.veg_curry_per_week, f"veg_curry_count={veg_count}", 80 * max(0, args.veg_curry_per_week - veg_count))

    keys = [s.c.key for s in slots]
    repeats = len(keys) - len(set(keys))
    rule("No repeated combo in week", repeats == 0, f"repeats={repeats}", 500 * repeats)

    for d in DAYS:
        ds = [s for s in slots if s.day == d]
        fried = sum(s.c.fried_count for s in ds)
        pulse = sum(s.c.pulse_count for s in ds)
        rule(f"{d}: max one fried item", fried <= 1, f"fried_count={fried}", 90 * max(0, fried - 1))
        rule(f"{d}: pulse max two", pulse <= 2, f"pulse_count={pulse}", 60 * max(0, pulse - 2))
        if pulse == 2:
            score += 8; rows.append({"Rule": f"{d}: pulse preference one", "Pass": False, "Detail": "pulse_count=2 allowed only if needed", "Penalty": 8})
        else:
            rows.append({"Rule": f"{d}: pulse preference one", "Pass": True, "Detail": f"pulse_count={pulse}", "Penalty": 0})

    for s in slots:
        bad, why = invalid_candidate(s.c)
        rule(f"{s.day} {s.meal}: session compatibility", not bad, why or "ok", 100 if bad else 0)
        if s.day in {"Monday", "Friday"} and s.meal == "Breakfast":
            rule(f"{s.day} breakfast no fried", s.c.fried_count == 0, f"fried_count={s.c.fried_count}", 100 * s.c.fried_count)
        if s.c.has_veg_curry and "cut fruits" in s.addons:
            rule(f"{s.day} {s.meal}: no cut fruit with veg curry", False, "cut fruits add-on with veg curry", 100)

    lsp = sum(s.meal == "Lunch" and s.c.special for s in slots)
    dsp = sum(s.meal == "Dinner" and s.c.special for s in slots)
    rule("Lunch specials target", lsp >= args.lunch_specials_per_week, f"lunch_specials={lsp}", 25 * max(0, args.lunch_specials_per_week - lsp))
    rule("Dinner specials target", dsp >= args.dinner_specials_per_week, f"dinner_specials={dsp}", 25 * max(0, args.dinner_specials_per_week - dsp))

    weekly_cost = round(sum(slot_cost(s, price_map) for s in slots), 2)
    rows.append({"Rule": "Estimated weekly cost per person", "Pass": True, "Detail": f"estimated_cost={weekly_cost:.2f} INR", "Penalty": 0})
    if args.target_budget_per_person_week is not None:
        target = float(args.target_budget_per_person_week)
        tol = float(args.budget_tolerance_percent) / 100.0
        low, high = target * (1 - tol), target * (1 + tol)
        ok = low <= weekly_cost <= high
        penalty = int(abs(weekly_cost - target) * float(args.budget_penalty_per_rupee)) if not ok else 0
        rule("Weekly budget target", ok, f"target={target:.2f}, tolerance=±{args.budget_tolerance_percent:.1f}%, estimated={weekly_cost:.2f}", penalty)

    return score, rows

def generate(cands: List[Candidate], week_start: date, args, used_df: pd.DataFrame) -> Tuple[List[Slot], List[Dict[str, object]], int]:
    rng = random.Random(args.seed)
    used = {str(r.key): pd.to_datetime(r.last_used_date, errors="coerce") for r in used_df.itertuples() if hasattr(r, "key")}
    by_meal = {m: [] for m in MEAL_ORDER}
    for c in cands:
        bad, _ = invalid_candidate(c)
        if not bad and c.meal_type in by_meal:
            by_meal[c.meal_type].append(c)
    meals = ["Breakfast", "Lunch"] + ([] if args.no_snacks else ["Snacks/Tea"]) + ["Dinner"]
    # Keep generation fast. The deduped database has thousands of historical combos;
    # using the most observed candidates per meal still gives high variety while avoiding long runs.
    max_per_meal = int(getattr(args, "max_candidates_per_meal", 1200) or 0)
    if max_per_meal > 0:
        for m in meals:
            by_meal[m] = sorted(by_meal[m], key=lambda c: (c.count, c.special), reverse=True)[:max_per_meal]
    for m in meals:
        if not by_meal[m]:
            raise ValueError(f"No usable candidates for {m}")
    best_slots, best_audit, best_score = [], [], 10**9
    for _ in range(args.attempts):
        slots, used_keys, fried, pulse = [], set(), {d: 0 for d in DAYS}, {d: 0 for d in DAYS}
        veg_so_far = lunch_sp = dinner_sp = 0
        failed = False
        for i, d in enumerate(DAYS):
            dt = week_start + timedelta(days=i)
            for meal in meals:
                pool = []
                for c in by_meal[meal]:
                    if c.key in used_keys: continue
                    if d in {"Monday", "Friday"} and meal == "Breakfast" and c.fried_count > 0: continue
                    if fried[d] + c.fried_count > 1: continue
                    if pulse[d] + c.pulse_count > 2: continue
                    pool.append(c)
                if not pool:
                    failed = True; break
                weights = [age_weight(c, dt, used, max(0, args.veg_curry_per_week - veg_so_far), rng) for c in pool]
                if meal == "Lunch" and lunch_sp < args.lunch_specials_per_week:
                    weights = [w * (1.8 if c.special else 1.0) for w, c in zip(weights, pool)]
                if meal == "Dinner" and dinner_sp < args.dinner_specials_per_week:
                    weights = [w * (1.8 if c.special else 1.0) for w, c in zip(weights, pool)]
                c = choose(pool, weights, rng)
                used_keys.add(c.key); fried[d] += c.fried_count; pulse[d] += c.pulse_count; veg_so_far += int(c.has_veg_curry)
                lunch_sp += int(meal == "Lunch" and c.special); dinner_sp += int(meal == "Dinner" and c.special)
                slots.append(Slot(d, dt, meal, c))
            if failed: break
        if failed: continue
        add_sides(slots, rng, args.fruits_per_week, args.salads_per_week)
        score, audit = audit_plan(slots, args, getattr(args, "_price_map", {}))
        if score < best_score:
            best_slots, best_audit, best_score = slots, audit, score
            if score == 0: break
    if not best_slots:
        raise RuntimeError("Could not generate a plan. Try increasing --attempts or relaxing constraints.")
    return best_slots, best_audit, best_score

# ---------------------------------------------------------------------
# Output workbook
# ---------------------------------------------------------------------
def weekly_table(slots: List[Slot], price_map: Dict[str, float]) -> pd.DataFrame:
    rows = []
    for d in DAYS:
        ds = [s for s in slots if s.day == d]
        row = {"Day": d, "Date": ds[0].date if ds else None}
        for m in MEAL_ORDER:
            s = next((x for x in ds if x.meal == m), None)
            row[m] = "" if not s else s.c.combo + (f" | ADD: {s.addons}" if s.addons else "")
        row["Estimated_Day_Cost_INR"] = day_cost(slots, d, price_map)
        rows.append(row)
    return pd.DataFrame(rows)

def details_table(slots: List[Slot], price_map: Dict[str, float]) -> pd.DataFrame:
    rows = []
    for s in slots:
        c = s.c
        rows.append({"Day": s.day, "Date": s.date, "Meal_Type": s.meal, "Combo": c.combo, "Add_Ons": s.addons, "Estimated_Cost_INR_Per_Person": slot_cost(s, price_map), "Notes": s.notes, "Source_Years": c.source_years, "Historical_Count": c.count, "Last_Seen_In_Source": None if c.last_seen is None else c.last_seen.date(), "Special_Flag": c.special, "Special_Type": c.special_type, "Has_Fruit": c.has_fruit, "Has_Cut_Fruit": c.has_cut_fruit, "Has_Salad": c.has_salad, "Has_Veg_Curry": c.has_veg_curry, "Has_Pulse": c.has_pulse, "Fried_Count": c.fried_count, "Griddled_Count": c.griddled_count, "Steamed_Count": c.steamed_count, "Pulse_Count": c.pulse_count, "Normalized_Key": c.key})
    return pd.DataFrame(rows)

def taxonomy_table(cands: List[Candidate]) -> pd.DataFrame:
    items = sorted({i for c in cands for i in c.items})
    return pd.DataFrame([{"Item": i, **item_tags(i)} for i in items])

def alias_table() -> pd.DataFrame:
    return pd.DataFrame([{"Alias": k, "Canonical": v, "Source": "Approved" if k in APPROVED_ALIAS_MAP else "Extra seed"} for k, v in sorted(ALIAS_MAP.items())])

def updated_used_log(slots: List[Slot], used_df: pd.DataFrame) -> pd.DataFrame:
    old = used_df.rename(columns={"normalized_key": "key"}).copy() if used_df is not None else pd.DataFrame(columns=["key", "last_used_date"])
    if "key" not in old.columns: old["key"] = []
    if "last_used_date" not in old.columns: old["last_used_date"] = pd.NaT
    new = pd.DataFrame({"key": [s.c.key for s in slots], "last_used_date": [s.date for s in slots]})
    out = pd.concat([old[["key", "last_used_date"]], new], ignore_index=True)
    out["last_used_date"] = pd.to_datetime(out["last_used_date"], errors="coerce")
    return out.groupby("key", as_index=False)["last_used_date"].max().rename(columns={"key": "normalized_key"}).sort_values("last_used_date", ascending=False)

def write_output(path: str, slots: List[Slot], audit: List[Dict[str, object]], score: int, cands: List[Candidate], used_df: pd.DataFrame, price_map: Dict[str, float]) -> None:
    weekly_cost = round(sum(slot_cost(s, price_map) for s in slots), 2)
    summary = pd.DataFrame([
        {"Metric": "Penalty Score", "Value": score},
        {"Metric": "All rules passed", "Value": "Yes" if score == 0 else "No - check Rule_Audit"},
        {"Metric": "Candidate combos", "Value": len(cands)},
        {"Metric": "Candidate database rows written", "Value": min(len(cands), 500)},
        {"Metric": "Selected meal slots", "Value": len(slots)},
        {"Metric": "Estimated weekly cost per person INR", "Value": weekly_cost},
        {"Metric": "Estimated average daily cost per person INR", "Value": round(weekly_cost / 7, 2)},
    ])
    # Keep the output workbook responsive. The source workbook remains the full database.
    display_cands = sorted(cands, key=lambda c: c.count, reverse=True)[:500]
    cand_df = pd.DataFrame([asdict(c) for c in display_cands])
    if not cand_df.empty:
        cand_df["estimated_cost_inr_per_person"] = [candidate_cost(c, price_map) for c in display_cands]
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        summary.to_excel(writer, index=False, sheet_name="Summary")
        weekly_table(slots, price_map).to_excel(writer, index=False, sheet_name="Weekly_Menu")
        pd.DataFrame(audit).to_excel(writer, index=False, sheet_name="Rule_Audit")
        details_table(slots, price_map).to_excel(writer, index=False, sheet_name="Selected_Details")
        updated_used_log(slots, used_df).to_excel(writer, index=False, sheet_name="Updated_Used_Log")
        alias_table().to_excel(writer, index=False, sheet_name="Alias_Map")
        selected_items = sorted({i for s in slots for i in s.c.items} | {i for s in slots for i in addon_items(s.addons)})
        pd.DataFrame([{"Item": i, "Estimated_Cost_INR": get_item_price(i, price_map), **item_tags(i)} for i in selected_items]).to_excel(writer, index=False, sheet_name="Selected_Item_Tags")
        cand_df.to_excel(writer, index=False, sheet_name="Candidate_Database")
        wb = writer.book
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]: cell.font = cell.font.copy(bold=True)
            for col_idx in range(1, ws.max_column + 1):
                vals = [ws.cell(row=r, column=col_idx).value for r in range(1, min(ws.max_row, 100) + 1)]
                width = max([len(str(v or "")) for v in vals] + [10]) + 2
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(width, 55)

# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser(description="Generate one week hostel menu from consolidated menu workbook.")
    p.add_argument("--input", required=True)
    p.add_argument("--output", default="weekly_menu.xlsx")
    p.add_argument("--week-start", default=None, help="Monday date, e.g. 2026-06-22")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--attempts", type=int, default=2000)
    p.add_argument("--used-log", default=None)
    p.add_argument("--no-snacks", action="store_true")
    p.add_argument("--fruits-per-week", type=int, default=3)
    p.add_argument("--salads-per-week", type=int, default=3)
    p.add_argument("--veg-curry-per-week", type=int, default=3)
    p.add_argument("--lunch-specials-per-week", type=int, default=1)
    p.add_argument("--dinner-specials-per-week", type=int, default=1)
    p.add_argument("--max-candidates-per-meal", type=int, default=1200, help="Speed control: use top N historical candidates per meal; set 0 to use all.")
    p.add_argument("--target-budget-per-person-week", type=float, default=None, help="Optional weekly food budget target per person in INR.")
    p.add_argument("--budget-tolerance-percent", type=float, default=10.0, help="Allowed ± percentage around the weekly target.")
    p.add_argument("--budget-penalty-per-rupee", type=float, default=1.0, help="Penalty added per INR outside the budget tolerance band.")
    return p.parse_args()

def main():
    args = parse_args()
    week_start = datetime.strptime(args.week_start, "%Y-%m-%d").date() if args.week_start else date.today() - timedelta(days=date.today().weekday())
    used_df = load_used_log(args.used_log)
    price_map = load_price_map(args.input)
    args._price_map = price_map
    cands = build_candidates(args.input)
    slots, audit, score = generate(cands, week_start, args, used_df)
    write_output(args.output, slots, audit, score, cands, used_df, price_map)
    print(f"Generated: {args.output}")
    print(f"Penalty score: {score}")
    if score != 0:
        print("Some rules/preferred constraints did not fully pass. Open Rule_Audit in the output workbook.")

if __name__ == "__main__":
    main()
