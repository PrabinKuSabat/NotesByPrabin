#!/usr/bin/env python3
"""
Browser UI for the Hostel Weekly Menu Generator.

Run:
    streamlit run menu_web_app.py

This app keeps the old command-line options hidden by default. The user only
chooses the week start date and budget, clicks Generate, and downloads Excel.
"""

from __future__ import annotations

import io
import os
import random
import tempfile
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import streamlit as st

import weekly_menu_generator_budget as gen

APP_DIR = Path(__file__).resolve().parent
DEFAULT_DB = APP_DIR / "hostel_menu_database.xlsx"
OUTPUT_DIR = APP_DIR / "generated_menus"
OUTPUT_DIR.mkdir(exist_ok=True)


@dataclass
class AppConfig:
    week_start: date
    target_budget_per_person_week: float | None
    budget_tolerance_percent: float
    number_of_students: int
    include_snacks: bool
    attempts: int
    seed: int
    max_candidates_per_meal: int
    fruits_per_week: int = 3
    salads_per_week: int = 3
    veg_curry_per_week: int = 3
    lunch_specials_per_week: int = 1
    dinner_specials_per_week: int = 1


def next_monday(today: date | None = None) -> date:
    today = today or date.today()
    days_ahead = (7 - today.weekday()) % 7
    return today + timedelta(days=days_ahead)


def save_uploaded_workbook(uploaded_file) -> Path:
    suffix = Path(uploaded_file.name).suffix or ".xlsx"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.getbuffer())
        return Path(tmp.name)


def build_args(cfg: AppConfig, price_map: dict[str, float]) -> SimpleNamespace:
    return SimpleNamespace(
        seed=cfg.seed,
        attempts=cfg.attempts,
        no_snacks=not cfg.include_snacks,
        fruits_per_week=cfg.fruits_per_week,
        salads_per_week=cfg.salads_per_week,
        veg_curry_per_week=cfg.veg_curry_per_week,
        lunch_specials_per_week=cfg.lunch_specials_per_week,
        dinner_specials_per_week=cfg.dinner_specials_per_week,
        max_candidates_per_meal=cfg.max_candidates_per_meal,
        target_budget_per_person_week=cfg.target_budget_per_person_week,
        budget_tolerance_percent=cfg.budget_tolerance_percent,
        budget_penalty_per_rupee=1.0,
        _price_map=price_map,
    )


def generate_menu(input_path: Path, cfg: AppConfig) -> tuple[Path, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    price_map = gen.load_price_map(str(input_path))
    args = build_args(cfg, price_map)
    used_df = gen.load_used_log(None)
    cands = gen.build_candidates(str(input_path))
    slots, audit, score = gen.generate(cands, cfg.week_start, args, used_df)

    output_path = OUTPUT_DIR / f"weekly_menu_{cfg.week_start.isoformat()}_budget.xlsx"
    gen.write_output(str(output_path), slots, audit, score, cands, used_df, price_map)

    weekly_df = gen.weekly_table(slots, price_map)
    audit_df = pd.DataFrame(audit)
    details_df = gen.details_table(slots, price_map)
    return output_path, weekly_df, audit_df, details_df


def money(x: float | int | None) -> str:
    if x is None:
        return "—"
    return f"₹{float(x):,.0f}"


def main() -> None:
    st.set_page_config(page_title="Hostel Weekly Menu Generator", page_icon="🍽️", layout="wide")

    st.title("🍽️ Hostel Weekly Menu Generator")
    st.caption("Choose the week and budget, then click Generate. No command-line options needed.")

    with st.sidebar:
        st.header("Menu Settings")
        uploaded = st.file_uploader(
            "Menu database Excel",
            type=["xlsx"],
            help="Use the default database, or upload the updated workbook after editing prices.",
        )

        if DEFAULT_DB.exists():
            use_default = st.checkbox("Use included hostel menu database", value=True)
        else:
            use_default = False

        week_start = st.date_input(
            "Week starting Monday",
            value=next_monday(),
            help="Pick the Monday for which the menu should be generated.",
        )

        number_of_students = st.number_input(
            "Number of students",
            min_value=1,
            max_value=5000,
            value=100,
            step=5,
            help="Only used for showing total estimated budget. Menu logic uses per-person cost.",
        )

        target_budget = st.number_input(
            "Budget per person for the week (₹)",
            min_value=0,
            max_value=5000,
            value=700,
            step=10,
            help="The generator tries to stay close to this value.",
        )

        tolerance = st.slider("Allowed budget variation", 0, 50, 10, format="±%d%%")
        include_snacks = st.checkbox("Include snacks/tea", value=True)

        with st.expander("Advanced settings"):
            fruits = st.number_input("Fruits per week", min_value=0, max_value=14, value=3)
            salads = st.number_input("Salads per week", min_value=0, max_value=14, value=3)
            veg_curry = st.number_input("Veg curry per week", min_value=0, max_value=14, value=3)
            lunch_specials = st.number_input("Lunch specials per week", min_value=0, max_value=7, value=1)
            dinner_specials = st.number_input("Dinner specials per week", min_value=0, max_value=7, value=1)
            attempts = st.number_input("Generation attempts", min_value=50, max_value=5000, value=500, step=50)
            max_candidates = st.number_input("Max candidates per meal", min_value=100, max_value=5000, value=1200, step=100)
            randomize = st.checkbox("Randomize each run", value=False)
            seed = random.randint(1, 999999) if randomize else st.number_input("Fixed seed", min_value=1, max_value=999999, value=42)

    if uploaded is not None and not use_default:
        input_path = save_uploaded_workbook(uploaded)
        source_label = uploaded.name
    elif DEFAULT_DB.exists():
        input_path = DEFAULT_DB
        source_label = DEFAULT_DB.name
    elif uploaded is not None:
        input_path = save_uploaded_workbook(uploaded)
        source_label = uploaded.name
    else:
        st.error("Please upload the hostel menu database Excel file.")
        st.stop()

    cfg = AppConfig(
        week_start=week_start,
        target_budget_per_person_week=float(target_budget) if target_budget > 0 else None,
        budget_tolerance_percent=float(tolerance),
        number_of_students=int(number_of_students),
        include_snacks=bool(include_snacks),
        attempts=int(attempts),
        seed=int(seed),
        max_candidates_per_meal=int(max_candidates),
        fruits_per_week=int(fruits),
        salads_per_week=int(salads),
        veg_curry_per_week=int(veg_curry),
        lunch_specials_per_week=int(lunch_specials),
        dinner_specials_per_week=int(dinner_specials),
    )

    st.info(f"Using database: {source_label}")

    col1, col2, col3 = st.columns(3)
    col1.metric("Week Start", cfg.week_start.isoformat())
    col2.metric("Budget / Person / Week", money(cfg.target_budget_per_person_week))
    col3.metric("Approx Total Budget", money((cfg.target_budget_per_person_week or 0) * cfg.number_of_students))

    generate_clicked = st.button("Generate Weekly Menu", type="primary", use_container_width=True)

    if generate_clicked:
        with st.spinner("Generating menu and checking rules..."):
            try:
                output_path, weekly_df, audit_df, details_df = generate_menu(input_path, cfg)
            except Exception as exc:
                st.error("Menu generation failed. Try increasing Generation attempts or loosening constraints in Advanced settings.")
                st.exception(exc)
                st.stop()

        weekly_cost = float(weekly_df["Estimated_Day_Cost_INR"].sum())
        total_week_cost = weekly_cost * cfg.number_of_students
        failed_rules = audit_df[audit_df["Pass"] == False] if "Pass" in audit_df.columns else pd.DataFrame()

        st.success("Menu generated successfully.")
        m1, m2, m3 = st.columns(3)
        m1.metric("Estimated / Person / Week", money(weekly_cost))
        m2.metric("Estimated Total / Week", money(total_week_cost))
        m3.metric("Failed Rule Checks", len(failed_rules))

        st.subheader("Weekly Menu")
        st.dataframe(weekly_df, use_container_width=True, hide_index=True)

        if not failed_rules.empty:
            st.subheader("Rules needing review")
            st.dataframe(failed_rules[["Rule", "Detail", "Penalty"]], use_container_width=True, hide_index=True)
        else:
            st.subheader("Rule Audit")
            st.write("All hard/preferred checks passed in this run.")

        st.subheader("Selected Meal Details")
        visible_cols = [
            "Day", "Date", "Meal_Type", "Combo", "Add_Ons", "Estimated_Cost_INR_Per_Person", "Notes",
            "Special_Flag", "Normalized_Key",
        ]
        st.dataframe(details_df[[c for c in visible_cols if c in details_df.columns]], use_container_width=True, hide_index=True)

        with open(output_path, "rb") as f:
            st.download_button(
                label="Download Excel Menu",
                data=f.read(),
                file_name=output_path.name,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )

        st.caption(f"Also saved locally at: {output_path}")
    else:
        st.subheader("How to use")
        st.write(
            "1. Keep the default database selected, or upload the updated Excel after changing item prices.\n\n"
            "2. Select the week start and budget.\n\n"
            "3. Click **Generate Weekly Menu** and download the Excel."
        )
        st.subheader("Built-in rules")
        st.write(
            "The app keeps your existing food rules fixed by default: fruits 3/week, salads 3/week, no fried breakfast on Monday/Friday, "
            "maximum one fried item per day, pulse control, griddled/steamed compatibility, low repetition, and approximate budget matching."
        )


if __name__ == "__main__":
    main()
