@echo off
cd /d "%~dp0"
echo Installing required packages if missing...
python -m pip install -r requirements.txt
echo Starting Hostel Menu App...
python -m streamlit run menu_web_app.py
pause
